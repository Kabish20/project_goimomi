from django.apps import AppConfig


class HolidaysConfig(AppConfig):
    name = 'Holidays'
